
<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['submit'])){

   $_SESSION['email'] = $_POST['email'];
   $_SESSION['email'] = filter_var($_SESSION['email'], FILTER_SANITIZE_STRING);
   $securityCode = md5(date("h:i:s"));
   $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
   $select_user->execute([$_SESSION['email']]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);
   


 if($select_user->execute()){


   
          require_once "mail.php";
          $mail->addAddress($_SESSION['email']);
          $mail->Subject = "Reset verification code";
          $mail->Body = '<h1> reset your password</h1>'
          . "<div> Account verification link" . "<div>" . 
          "<a href='http://localhost/11/chang.php?code=".$securityCode  . "'>" . "http://localhost/11/chang.php?code=" .$securityCode . "</a>";
          ;
          $mail->setFrom("aimnameen57@gmail.com", "Shopi");
          $mail->send();
        echo "send successfully";
      

      }
     

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="form-container">

   <form action="" method="post">
      <h3>register now</h3>
      <input type="email" name="email" required placeholder="enter your email" maxlength="50"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="register now" class="btn" name="submit">
   </form>

</section>



<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>