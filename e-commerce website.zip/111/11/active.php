<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

<main class="container">

<?php
include 'components/connect.php';
if(isset($_GET['code'])){
$checkCode = $conn->prepare("select security_code from users where security_code = :SECURITY_CODE");
$checkCode->bindParam("SECURITY_CODE",$_GET['code']);
$checkCode->execute();
	
if($checkCode->rowCount()>0){
   $update = $conn->prepare("update users set security_code =:NEWSECURITY_CODE ,
 Activated=true where security_code = :SECURITY_CODE");
$securityCode = md5(date("h:i:s"));
$update->bindParam("NEWSECURITY_CODE",$securityCode);
$update->bindParam("SECURITY_CODE",$_GET['code']);


if($update->execute()){
    echo '<div class="alert alert-success" role="alert">
  your account has been successfully verified😊
  </div>';
  echo '<a class="btn btn-warning" href="user_login.php">login</a>';}
}
else{
    echo '<div class="alert alert-danger" role="alert">
    this code is no longer valid for use 😢
  </div>';
}}
?>
</main>